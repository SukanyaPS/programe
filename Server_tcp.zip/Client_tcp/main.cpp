#include <arpa/inet.h>
#include <cstring>
#include <iostream>
#include <stdio.h>
#include <winsock2.h>
#include <ws2tcpip.h>

int main() {
  // Create a socket
  int clientSocket = socket(AF_INET, SOCK_STREAM, 0);
  if (clientSocket == -1) {
    std::cerr << "Failed to create socket." << std::endl;
    return 1;
  }

  // Prepare the server address
  sockaddr_in serverAddress{};
  serverAddress.sin_family = AF_INET;
  serverAddress.sin_port = htons(8080); // Port number
  if (inet_pton(AF_INET, "127.0.0.1", &(serverAddress.sin_addr)) <= 0) {
    std::cerr << "Invalid address." << std::endl;
    return 1;
  }

  // Connect to the server
  if (connect(clientSocket, (struct sockaddr *)&serverAddress,
              sizeof(serverAddress)) < 0) {
    std::cerr << "Failed to connect." << std::endl;
    return 1;
  }

  // Receive and print the server welcome message
  char buffer[1024];
  memset(buffer, 0, sizeof(buffer));
  int bytesRead = recv(clientSocket, buffer, sizeof(buffer), 0);
  if (bytesRead > 0) {
    std::cout << "Server message: " << buffer << std::endl;
  }

  // Send client messages to the server
  std::string message;
  while (true) {
    std::cout << "Enter a message to send to the server (or 'quit' to exit): ";
    std::cin >> message;

    if (message == "quit") {
      break;
    }

    if (send(clientSocket, message.c_str(), message.length(), 0) < 0) {
      std::cerr << "Failed to send message." << std::endl;
      break;
    }
  }

  // Close the client socket
  closesocket(clientSocket);

  return 0;
}
