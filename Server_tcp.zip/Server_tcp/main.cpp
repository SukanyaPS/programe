#include <cstring>
#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>

int main() {
  // Create a socket
  int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
  if (serverSocket == -1) {
    std::cerr << "Failed to create socket." << std::endl;
    return 1;
  }

  // Prepare the server address
  sockaddr_in serverAddress{};
  serverAddress.sin_family = AF_INET;
  serverAddress.sin_addr.s_addr = INADDR_ANY;
  serverAddress.sin_port = htons(8080); // Port number

  // Bind the socket to the specified address and port
  if (bind(serverSocket, (struct sockaddr *)&serverAddress,
           sizeof(serverAddress)) < 0) {
    std::cerr << "Failed to bind." << std::endl;
    return 1;
  }

  // Listen for incoming connections
  if (listen(serverSocket, 3) < 0) {
    std::cerr << "Failed to listen." << std::endl;
    return 1;
  }

  std::cout << "Server started. Waiting for connections..." << std::endl;

  while (true) {
    // Accept a client connection
    int clientSocket = accept(serverSocket, nullptr, nullptr);
    if (clientSocket < 0) {
      std::cerr << "Failed to accept connection." << std::endl;
      return 1;
    }

    std::cout << "Client connected." << std::endl;

    // Handle client requests
    char buffer[1024];
    memset(buffer, 0, sizeof(buffer));
    std::string welcomeMessage = "Welcome to the server!";
    send(clientSocket, welcomeMessage.c_str(), welcomeMessage.length(), 0);

    // Receive and print client messages
    while (true) {
      int bytesRead = recv(clientSocket, buffer, sizeof(buffer), 0);
      if (bytesRead <= 0) {
        break;
      }

      std::cout << "Client message: " << buffer << std::endl;
      memset(buffer, 0, sizeof(buffer));
    }

    std::cout << "Client disconnected." << std::endl;

    // Close the client socket
    closesocket(clientSocket);
  }

  // Close the server socket
  closesocket(serverSocket);

  return 0;
}
